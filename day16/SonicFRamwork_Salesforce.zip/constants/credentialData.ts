

/* const managerName: any = data.managerName
const commonUser: any = data.commonUser
const internalUser: any = data.internalUser
const externalUser: any = data.externalUser
const teamUser1: any = data.teamUser1
const teamUser2: any = data.teamUser2 */

export let credentials = {

    ADMINLOGIN: {
        username: "majay3574@gmail.com",
        password: "Ajaymichael@123"
    },
    USERLOGIN: {
        username: "Ranjini",
        password: "Welcome1@"
    }
};