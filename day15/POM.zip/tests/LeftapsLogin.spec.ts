
import { test } from "../utitliy/myFixture"
test(`Learn to integrate oops with pw`,async({lp})=>{ 
   await lp.verifyTitle()    
   
})