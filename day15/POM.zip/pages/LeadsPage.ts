import { MyHomePage } from "./MyHomePage";


export class LeadsPage extends MyHomePage{

 async clickCreate(){
    
 }


}